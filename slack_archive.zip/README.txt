GET APITOKEN AT BOTTOM OF THIS PAGE: 
https://api.slack.com/web

INSERT TOKEN INTO slack_archive.sh in 1 place. 

RUN ./slack_archive.sh
