#!/bin/sh

export TOKEN=[YOUR_TOKEN_HERE]  ### GET TOKEN FROM BOTTOM OF THIS PAGE: https://api.slack.com/web
echo $TOKEN
pip install slacker
mkdir slack_archive
cd slack_archive
#cp ../slack/slack_history.py .
#cp ../slack/slack2html.php .
python ../slack_history.py --token=$TOKEN --skipPrivateChannels --skipDirectMessages
python ../slack_history.py --token=$TOKEN --skipChannels
mkdir full 
cp users.json full/
cp channels.json full/
cd channel/
zip -r ../channel.zip .
cd ../direct_message/
zip -r ../direct_message.zip .
cd ../private_channels/
zip -r ../private_channels.zip .
cd ../full
unzip -qo ../channel.zip 
unzip -qo ../private_channels.zip 
unzip -qo ../direct_message.zip 
cp ../../slack2html.php .
php slack2html.php
echo "OPEN YOUR BROWSER TO file:/// and navigate locally to slack2html/index.html"
